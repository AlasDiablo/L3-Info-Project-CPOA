# Changelog

## Itération 1

### Ajout

- de la fonctionnalité "Crée un utilisateur"
- de la fonctionnalité "Crée un PC"
- de la fonctionnalité "Changer un utilisateur"
- de la fonctionnalité "Changer un PC"
- de la documentation
