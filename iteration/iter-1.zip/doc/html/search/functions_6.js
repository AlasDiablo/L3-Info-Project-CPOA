var searchData=
[
  ['refresh_69',['refresh',['../class_main_window.html#ab27297114529e4c16d6d8d7a54927a0e',1,'MainWindow']]],
  ['removepc_70',['removePC',['../classmodel_1_1_data.html#a0f0ba81f06896c8fa5b8417c96ee180c',1,'model::Data::removePC(std::string name)'],['../classmodel_1_1_data.html#a2fe4ed8ede8c75b3dc09c199422cfe1f',1,'model::Data::removePC(int i)']]],
  ['removeuser_71',['removeUser',['../classmodel_1_1_data.html#ad34dbb3e144580ec8370118f5cb19359',1,'model::Data::removeUser(std::string name)'],['../classmodel_1_1_data.html#a2a034fa0c3e6412b9eb93393eab00e7a',1,'model::Data::removeUser(int i)']]]
];
