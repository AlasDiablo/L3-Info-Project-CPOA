var searchData=
[
  ['data_59',['Data',['../classmodel_1_1_data.html#ab84ea9e2a46546b39590f9385fec1419',1,'model::Data']]]
];
