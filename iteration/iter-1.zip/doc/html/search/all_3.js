var searchData=
[
  ['getcreatorname_12',['getCreatorName',['../classmodel_1_1_p_c.html#ae625f3ec019a3e48e9653afbfbfa7889',1,'model::PC']]],
  ['getname_13',['getName',['../classmodel_1_1_p_c.html#a6ade3e004269d523cd245c6393e28570',1,'model::PC::getName()'],['../classmodel_1_1_user.html#a65e0349a829857521c488e26b53a2f7e',1,'model::User::getName()']]],
  ['getpc_14',['getPC',['../classmodel_1_1_data.html#a66cfbe43a4ef303833603d38acb6f93d',1,'model::Data::getPC(int i)'],['../classmodel_1_1_data.html#afd3832d3dcbc8ecbbe4e681d34fda8c8',1,'model::Data::getPC(std::string name)'],['../classmodel_1_1_data.html#a1ad815a8dd31ba2b56a186d2f782da95',1,'model::Data::getPC()']]],
  ['getpcsize_15',['getPCSize',['../classmodel_1_1_data.html#a3a062cafcf9590c2e0158058790a6a0c',1,'model::Data']]],
  ['getuser_16',['getUser',['../classmodel_1_1_data.html#a0a730edd9d33ba978abea7699b8ca276',1,'model::Data::getUser(int i)'],['../classmodel_1_1_data.html#a27e8f1b32b41a348b800f72a45b12cf4',1,'model::Data::getUser(std::string name)'],['../classmodel_1_1_data.html#a181a9c1ccf85cb1f0f7455f6f4a34063',1,'model::Data::getUser()']]],
  ['getusersize_17',['getUserSize',['../classmodel_1_1_data.html#ade003655de489350981b89ddf5977ddb',1,'model::Data']]]
];
