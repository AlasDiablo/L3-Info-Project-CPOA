var searchData=
[
  ['pc_24',['PC',['../classmodel_1_1_p_c.html',1,'model::PC'],['../classmodel_1_1_p_c.html#a3adc643f5e3821da195e8e2a7ffce31b',1,'model::PC::PC()'],['../classmodel_1_1_p_c.html#a1c9d464fabaaed10a265fae3e68b8b90',1,'model::PC::PC(std::string name, User creator)']]],
  ['pc_2ecpp_25',['pc.cpp',['../pc_8cpp.html',1,'']]],
  ['pc_2eh_26',['pc.h',['../pc_8h.html',1,'']]]
];
