var searchData=
[
  ['setname_30',['setName',['../classmodel_1_1_p_c.html#aa653e08567b11ef20e1c36f1bc5daff2',1,'model::PC']]]
];
