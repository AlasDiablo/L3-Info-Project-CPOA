var searchData=
[
  ['addpc_52',['addPC',['../classmodel_1_1_data.html#a6e0c92744e871fa7efca6cf0e01235de',1,'model::Data']]],
  ['adduser_53',['addUser',['../classmodel_1_1_data.html#af7c8cc170e9f8f8f37694b97515378f9',1,'model::Data']]]
];
