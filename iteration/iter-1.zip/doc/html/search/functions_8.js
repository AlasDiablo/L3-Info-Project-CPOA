var searchData=
[
  ['user_73',['User',['../classmodel_1_1_user.html#afbac2a73039a6c949a2d08f2abb80331',1,'model::User::User()'],['../classmodel_1_1_user.html#a22331c3f7fbad02b368420b51d079929',1,'model::User::User(std::string name)']]]
];
