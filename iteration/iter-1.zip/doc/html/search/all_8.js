var searchData=
[
  ['user_31',['User',['../classmodel_1_1_user.html',1,'model::User'],['../classmodel_1_1_user.html#afbac2a73039a6c949a2d08f2abb80331',1,'model::User::User()'],['../classmodel_1_1_user.html#a22331c3f7fbad02b368420b51d079929',1,'model::User::User(std::string name)']]],
  ['user_2ecpp_32',['user.cpp',['../user_8cpp.html',1,'']]],
  ['user_2eh_33',['user.h',['../user_8h.html',1,'']]]
];
