var searchData=
[
  ['pc_68',['PC',['../classmodel_1_1_p_c.html#a3adc643f5e3821da195e8e2a7ffce31b',1,'model::PC::PC()'],['../classmodel_1_1_p_c.html#a1c9d464fabaaed10a265fae3e68b8b90',1,'model::PC::PC(std::string name, User creator)']]]
];
