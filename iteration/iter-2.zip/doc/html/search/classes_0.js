var searchData=
[
  ['admin_54',['Admin',['../classmodel_1_1_admin.html',1,'model']]]
];
