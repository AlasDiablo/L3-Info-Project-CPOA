var searchData=
[
  ['pc_102',['PC',['../classmodel_1_1_p_c.html#a3adc643f5e3821da195e8e2a7ffce31b',1,'model::PC::PC()'],['../classmodel_1_1_p_c.html#a1c9d464fabaaed10a265fae3e68b8b90',1,'model::PC::PC(std::string name, User creator)']]],
  ['productor_103',['Productor',['../classmodel_1_1_productor.html#a159997321ecc7d2430c589d56849944b',1,'model::Productor::Productor()'],['../classmodel_1_1_productor.html#ae38f14c6da86b172255c8f3a8d2de5df',1,'model::Productor::Productor(std::string name)']]]
];
