var searchData=
[
  ['refresh_104',['refresh',['../class_main_window.html#ab27297114529e4c16d6d8d7a54927a0e',1,'MainWindow']]],
  ['removeadmin_105',['removeAdmin',['../classmodel_1_1_data.html#ad3a1880651f3de072e9c4b86fd510757',1,'model::Data::removeAdmin(std::string name)'],['../classmodel_1_1_data.html#ac7ad923879bc927ba1a8a924b092a8e4',1,'model::Data::removeAdmin(int i)']]],
  ['removepc_106',['removePC',['../classmodel_1_1_data.html#a0f0ba81f06896c8fa5b8417c96ee180c',1,'model::Data::removePC(std::string name)'],['../classmodel_1_1_data.html#a2fe4ed8ede8c75b3dc09c199422cfe1f',1,'model::Data::removePC(int i)']]],
  ['removeproducteur_107',['removeProducteur',['../classmodel_1_1_p_c.html#a4cff72d8a7542b07d38566e4df2dfb04',1,'model::PC']]],
  ['removeproductor_108',['removeProductor',['../class_controller_p_c.html#aeab2365bc756c092c04f9cec05f37cb7',1,'ControllerPC']]],
  ['removeuser_109',['removeUser',['../classmodel_1_1_data.html#ad34dbb3e144580ec8370118f5cb19359',1,'model::Data::removeUser(std::string name)'],['../classmodel_1_1_data.html#a2a034fa0c3e6412b9eb93393eab00e7a',1,'model::Data::removeUser(int i)']]]
];
