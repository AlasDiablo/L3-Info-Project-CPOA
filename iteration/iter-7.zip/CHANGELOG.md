# Changelog

## Itération 6

### Ajout
- modele order
- fonction de la base de donnée sur les order

## Itération 5

### Ajout
- finalisation de la base de donnée

## Itération 4

### Ajout
- creation d'un skellette pour un base de donnée sqlite
- creation d'un skellette pour un base de donnée sqlite

### Changement
- correction de bug


## Itération 3

### Ajout
- du modele du produit


## Itération 2

### Ajout

- de la fonctionnalité "Supprimer un PC"
- du modele du producteur
- du modele de l'administrateur
- de la documentation pour productor, pc
- de controle sur l'interface pour creer un Admin
- de la fonctionnalité "Verifier un PC"

### Changement

- du pc pour supporter les producteurs
- de data pour supporter productor et admin
- de MainWindow
- de controller qui est maintenant separer en deux fichier (controllerPC)

## Itération 1

### Ajout

- de la fonctionnalité "Crée un utilisateur"
- de la fonctionnalité "Crée un PC"
- de la fonctionnalité "Changer un utilisateur"
- de la fonctionnalité "Changer un PC"
- de la documentation
