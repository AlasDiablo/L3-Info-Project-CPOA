var searchData=
[
  ['getadmin_92',['getAdmin',['../classmodel_1_1_data.html#a393f048773f73ec905515ab20094726d',1,'model::Data::getAdmin(int i)'],['../classmodel_1_1_data.html#abe6a0cb8d49756750ddb958a316f5556',1,'model::Data::getAdmin(std::string name)'],['../classmodel_1_1_data.html#a9478d8c7464f06e4edae9cda09d8b176',1,'model::Data::getAdmin()']]],
  ['getcheck_93',['getCheck',['../classmodel_1_1_p_c.html#a73533987989e6e62881b75d7946f13cd',1,'model::PC']]],
  ['getcreatorname_94',['getCreatorName',['../classmodel_1_1_p_c.html#ae625f3ec019a3e48e9653afbfbfa7889',1,'model::PC']]],
  ['getname_95',['getName',['../classmodel_1_1_admin.html#a3ce4526c2173df0a8cbc6bf70ec47a05',1,'model::Admin::getName()'],['../classmodel_1_1_p_c.html#a6ade3e004269d523cd245c6393e28570',1,'model::PC::getName()'],['../classmodel_1_1_productor.html#ae1930d2e39391bfa21dc1ea39d8f74e1',1,'model::Productor::getName()'],['../classmodel_1_1_user.html#a65e0349a829857521c488e26b53a2f7e',1,'model::User::getName()']]],
  ['getpc_96',['getPC',['../classmodel_1_1_data.html#a66cfbe43a4ef303833603d38acb6f93d',1,'model::Data::getPC(int i)'],['../classmodel_1_1_data.html#afd3832d3dcbc8ecbbe4e681d34fda8c8',1,'model::Data::getPC(std::string name)'],['../classmodel_1_1_data.html#a1ad815a8dd31ba2b56a186d2f782da95',1,'model::Data::getPC()']]],
  ['getpcsize_97',['getPCSize',['../classmodel_1_1_data.html#a3a062cafcf9590c2e0158058790a6a0c',1,'model::Data']]],
  ['getuser_98',['getUser',['../classmodel_1_1_data.html#a0a730edd9d33ba978abea7699b8ca276',1,'model::Data::getUser(int i)'],['../classmodel_1_1_data.html#a27e8f1b32b41a348b800f72a45b12cf4',1,'model::Data::getUser(std::string name)'],['../classmodel_1_1_data.html#a181a9c1ccf85cb1f0f7455f6f4a34063',1,'model::Data::getUser()']]],
  ['getusersize_99',['getUserSize',['../classmodel_1_1_data.html#ade003655de489350981b89ddf5977ddb',1,'model::Data']]]
];
