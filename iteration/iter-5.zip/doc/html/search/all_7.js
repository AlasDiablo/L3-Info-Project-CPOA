var searchData=
[
  ['setcheck_48',['setCheck',['../classmodel_1_1_p_c.html#aece0883a9ef73d40067766a7fdebb543',1,'model::PC']]],
  ['setname_49',['setName',['../classmodel_1_1_p_c.html#aa653e08567b11ef20e1c36f1bc5daff2',1,'model::PC']]]
];
