var searchData=
[
  ['data_90',['Data',['../classmodel_1_1_data.html#ab84ea9e2a46546b39590f9385fec1419',1,'model::Data']]],
  ['deletepc_91',['deletePC',['../class_controller_p_c.html#a62263817d4bba141b2331623ec512b2c',1,'ControllerPC']]]
];
