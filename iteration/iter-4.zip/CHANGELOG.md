# Changelog

## Itération 2

### Ajout

- de la fonctionnalité "Supprimer un PC"
- du modele du producteur
- du modele de l'administrateur
- de la documentation pour productor, pc
- de controle sur l'interface pour creer un Admin
- de la fonctionnalité "Verifier un PC"

### Changement

- du pc pour supporter les producteurs
- de data pour supporter productor et admin
- de MainWindow
- de controller qui est maintenant separer en deux fichier (controllerPC)

## Itération 1

### Ajout

- de la fonctionnalité "Crée un utilisateur"
- de la fonctionnalité "Crée un PC"
- de la fonctionnalité "Changer un utilisateur"
- de la fonctionnalité "Changer un PC"
- de la documentation
